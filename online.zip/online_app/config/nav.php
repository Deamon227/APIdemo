<?php
return [
    [
        'icon' => 'home',
        'name' => 'Overview',
        'route' => 'get_admin.home',
        'prefix' => ['']
    ],
    [
        'icon' => 'layers',
        'name' => 'Category',
        'route' => 'get_admin.category.index',
        'prefix' => ['category']
    ],
    [
        'icon' => 'shopping-cart',
        'name' => 'Products',
        'route' => 'get_admin.product.index',
        'prefix' => ['products']
    ],
    [
        'icon' => 'users',
        'name' => 'Members',
        'route' => 'get_admin.member.index',
        'prefix' => ['member']
    ],
    // [
    //     'icon' => 'bar-chart-2',
    //     'name' => 'Report',
    //     'route' => '',
    //     'prefix' => ['']
    // ]
];
