@extends('backend.layout.app_backend')
@section('content')
    <div class="d-flex justify-content-between align-items-center">
        <h2>Member list</h2>
        <a href="{{ route('get_admin.member.create') }}">Add members</a>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Avatar</th>
                    <th>Member name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Address</th>
                    <th>Gender</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($users ?? [] as $item)
            <tr>
                <td>{{ $item->id }}</td>
                <td>{{ $item->avatar }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ $item->email }}</td>
                <td>{{ $item->password }}</td>
                <td>{{ $item->address }}</td>
                <td>{{ $item->gender }}</td>
                <td>
                    <a href="{{ route('get_admin.member.update', $item->id) }}">Edit</a>
                    <a href="javascript:;void(0)">|</a>
                    <a href="{{ route('get_admin.member.delete', $item->id) }}">Delete</a>
                </td>
            </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@stop
