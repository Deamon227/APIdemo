<form method="POST" action="" autocomplete="off">
    @csrf
    <div class="form-group">
        <label for="exampleInputEmail1">Member name</label>
        <input type="text" name="name" placeholder="Name..." class="form-control"
            value="{{ old('name', $users->name ?? '') }}">
        @error('name')
            <small id="emailHelp" class="form-text text-danger">{{ $errors->first('name') }}</small>
        @enderror
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Email</label>
        <input type="email" name="email" placeholder="Email..." class="form-control"
            value="{{ old('email', $users->email ?? '') }}" id="exampleInputEmail1" aria-describedby="emailHelp">
        @error('email')
            <small id="emailHelp" class="form-text text-danger">{{ $errors->first('email') }}</small>
        @enderror
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" name="password" class="form-control"
            value="{{ old('password', $users->password ?? '') }}" id="exampleInputPassword1">
        @error('password')
            <small id="emailHelp" class="form-text text-danger">{{ $errors->first('password') }}</small>
        @enderror
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Address</label>
        <input type="text" name="address" placeholder="Address..." class="form-control"
            value="{{ old('address', $users->address ?? '') }}">
        @error('address')
            <small id="emailHelp" class="form-text text-danger">{{ $errors->first('address') }}</small>
        @enderror
    </div>
    <div>
        <label for="exampleInputEmail1">Gender:</label>
        <select name="gender">
            <option value="None">Choose your gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Others">Others</option>
        </select>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Profile picture</label>
        <input type="file" class="form-control" name="avatar">
    </div>
    <button type="submit" class="btn btn-primary">Save</button>
</form>
