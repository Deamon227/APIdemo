<form method="POST" action="" autocomplete="off">
    @csrf
    <div class="form-group">
        <label for="exampleInputEmail1">Category name</label>
        <input type="text" name="name" placeholder="Category name" class="form-control"
            value="{{ old('name', $categories->name ?? '') }}">
        @error('name')
            <small id="emailHelp" class="form-text text-danger">{{ $errors->first('name') }}</small>
        @enderror
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Description</label>
        <textarea name="description" class="form-control" cols="30", rows="3">{{ old('description', $categories->description ?? '') }}</textarea>
        @error('description')
            <small id="emailHelp" class="form-text text-danger">{{ $errors->first('description') }}</small>
        @enderror
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Image</label>
        <input type="file" class="form-control" name="avatar">
    </div>
    <button type="submit" class="btn btn-primary">Save</button>
</form>
