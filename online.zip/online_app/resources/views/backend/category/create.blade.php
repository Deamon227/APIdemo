@extends('backend.layout.app_backend')
@section('content')
    <div class="d-flex justify-content-between align-items-center">
        <h2>Add items</h2>
        <a href="{{ route('get_admin.category.index') }}">Return</a>
    </div>
    <div class="row">
        <div class="col-md-8">
            @include('backend.category.form')
        </div>
    </div>
@stop
