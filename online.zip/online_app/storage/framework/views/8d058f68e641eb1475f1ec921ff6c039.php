<form method="POST" action="" autocomplete="off">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputEmail1">Member name</label>
        <input type="text" name="name" placeholder="Name..." class="form-control"
            value="<?php echo e(old('name', $users->name ?? '')); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('name')); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Email</label>
        <input type="email" name="email" placeholder="Email..." class="form-control"
            value="<?php echo e(old('email', $users->email ?? '')); ?>" id="exampleInputEmail1" aria-describedby="emailHelp">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('email')); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" name="password" class="form-control"
            value="<?php echo e(old('password', $users->password ?? '')); ?>" id="exampleInputPassword1">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('password')); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Address</label>
        <input type="text" name="address" placeholder="Address..." class="form-control"
            value="<?php echo e(old('address', $users->address ?? '')); ?>">
        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('address')); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <label for="exampleInputEmail1">Gender:</label>
        <select name="gender">
            <option value="None">Choose your gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Others">Others</option>
        </select>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Profile picture</label>
        <input type="file" class="form-control" name="avatar">
    </div>
    <button type="submit" class="btn btn-primary">Save</button>
</form>
<?php /**PATH C:\xampp\htdocs\Laravel\online_app\resources\views/backend/member/form.blade.php ENDPATH**/ ?>