<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h2>Update info</h2>
        <a href="<?php echo e(route('get_admin.member.index')); ?>">Return</a>
    </div>
    <div class="row">
        <div class="col-md-8">
            <?php echo $__env->make('backend.member.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app_backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\online_app\resources\views/backend/member/update.blade.php ENDPATH**/ ?>