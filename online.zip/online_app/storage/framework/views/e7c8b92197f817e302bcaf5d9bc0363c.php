<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h2>Member list</h2>
        <a href="<?php echo e(route('get_admin.member.create')); ?>">Add members</a>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Avatar</th>
                    <th>Member name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Address</th>
                    <th>Gender</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->avatar); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->password); ?></td>
                <td><?php echo e($item->address); ?></td>
                <td><?php echo e($item->gender); ?></td>
                <td>
                    <a href="<?php echo e(route('get_admin.member.update', $item->id)); ?>">Edit</a>
                    <a href="javascript:;void(0)">|</a>
                    <a href="<?php echo e(route('get_admin.member.delete', $item->id)); ?>">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app_backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\online_app\resources\views/backend/member/index.blade.php ENDPATH**/ ?>