<form method="POST" action="" autocomplete="off">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputEmail1">Category name</label>
        <input type="text" name="name" placeholder="Category name" class="form-control"
            value="<?php echo e(old('name', $categories->name ?? '')); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('name')); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleInputEmail1">Description</label>
        <textarea name="description" class="form-control" cols="30", rows="3"><?php echo e(old('description', $categories->description ?? '')); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small id="emailHelp" class="form-text text-danger"><?php echo e($errors->first('description')); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group">
        <label for="exampleInputPassword1">Image</label>
        <input type="file" class="form-control" name="avatar">
    </div>
    <button type="submit" class="btn btn-primary">Save</button>
</form>
<?php /**PATH C:\xampp\htdocs\Laravel\online_app\resources\views/backend/category/form.blade.php ENDPATH**/ ?>