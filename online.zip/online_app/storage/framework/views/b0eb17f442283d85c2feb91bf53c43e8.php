<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center">
        <h2>Category</h2>
        <a href="<?php echo e(route('get_admin.category.create')); ?>">Add items</a>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Avatar</th>
                    <th>Category name</th>
                    <th>Slug</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->avatar); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->slug); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td><?php echo e($item->updated_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('get_admin.category.update', $item->id)); ?>">Edit</a>
                            <a href="javascript:;void(0)">|</a>
                            <a href="<?php echo e(route('get_admin.category.delete', $item->id)); ?>">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app_backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\online_app\resources\views/backend/category/index.blade.php ENDPATH**/ ?>