<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MemberRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|unique:users,name|max:255',
            'email' => 'required|unique:users,email|max:255',
            'password' => 'required',
            'address' => 'required',
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'Username must not be empty',
            'name.unique' => 'Username already exists',
            'email.required' => 'Email must not be empty',
            'email.unique' => 'Email already used to register an account',
            'password.required' => 'Password must not be empty',
            'address.required' => 'Address must not be empty',
        ];
    }
}
