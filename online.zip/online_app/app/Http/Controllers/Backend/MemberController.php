<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MemberRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class MemberController extends Controller
{
    public function index()
    {
        $users = User::orderBy('id')->paginate(20);
        $viewdata = [
            'users' => $users
        ];
        return view('backend.member.index', $viewdata);
    }

    public function create()
    {
        return view('backend.member.create');
    }

    public function store(MemberRequest $request)
    {
        try {
            $data = $request->except('_token', 'avatar');
            $data['created_at'] = Carbon::now('Asia/Ho_Chi_Minh');
            $member = User::create($data);
        } catch (Exception $e) {
            Log::error("ERROR => MemberController@store => " . $e->getMessage());
            return redirect()->route('get_admin.member.create');
        }
        return redirect()->route('get_admin.member.index');
    }

    public function edit($id)
    {
        $users = User::findOrFail($id);
        return view('backend.member.update', compact('users'));
    }

    public function update(MemberRequest $request, $id)
    {
        try {
            $data = $request->except('_token', 'avatar');
            $data['created_at'] = Carbon::now('Asia/Ho_Chi_Minh');
            User::find($id)->update($data);
        } catch (Exception $e) {
            Log::error("ERROR => MemberController@store => " . $e->getMessage());
            return redirect()->route('get_admin.member.update');
        }
        return redirect()->route('get_admin.member.index');
    }

    public function delete(Request $request, $id)
    {
        try {
            $user = User::findOrFail($id);
            if ($user) $user->delete();
        } catch (Exception $e) {
            Log::error("ERROR => MemberController@delete => " . $e->getMessage());
        }
        return redirect()->route('get_admin.member.index');
    }
}
