<?php

use App\Http\Controllers\Backend;
use App\Http\Controllers\Frontend;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::group(['namespace' => 'Frontend'], function (){
    Route::get('', [Frontend\HomeController::class, 'index']) -> name('get.home');
});

Route::group(['namespace' => 'Backend', 'prefix' => 'admin'], function (){
    Route::get('', [Backend\HomeController::class, 'index']) -> name('get_admin.home');
    Route::group(['prefix' => 'category'], function (){
        Route::get('', [Backend\CategoryController::class, 'index']) -> name('get_admin.category.index');
        Route::get('create', [Backend\CategoryController::class, 'create']) -> name('get_admin.category.create');
        Route::post('create', [Backend\CategoryController::class, 'store']) -> name('get_admin.category.store');

        Route::get('update/{id}', [Backend\CategoryController::class, 'edit']) -> name('get_admin.category.update');
        Route::post('update/{id}', [Backend\CategoryController::class, 'update']) -> name('get_admin.category.update');
        Route::get('delete/{id}', [Backend\CategoryController::class, 'delete']) -> name('get_admin.category.delete');
    });
    Route::group(['prefix' => 'products'], function (){
        Route::get('', [Backend\ProductController::class, 'index']) -> name('get_admin.product.index');
    });
    Route::group(['prefix' => 'member'], function (){
        Route::get('', [Backend\MemberController::class, 'index']) -> name('get_admin.member.index');
        Route::get('create', [Backend\MemberController::class, 'create']) -> name('get_admin.member.create');
        Route::post('create', [Backend\MemberController::class, 'store']) -> name('get_admin.member.store');

        Route::get('update/{id}', [Backend\MemberController::class, 'edit']) -> name('get_admin.member.update');
        Route::post('update/{id}', [Backend\MemberController::class, 'update']) -> name('get_admin.member.update');
        Route::get('delete/{id}', [Backend\MemberController::class, 'delete']) -> name('get_admin.member.delete');
    });
});
